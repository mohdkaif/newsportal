<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['cache_dir'] = APPPATH.'cache/web/';
$config['cache_default_expires'] = 0;

?>